
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import InventoryList from './components/InventoryList';
import NewInventoryItem from './components/NewInventoryItem';
import Sidebar from './components/Sidebar.js';
import Topbar from './components/Topbar.js';
import Breadcrumb from './components/Breadcrumb.js';
import './App.css';
import InventoryView from './components/InventoryView.js';

function App() {
  return (
    <Router>
      <div className="App">
        <Sidebar />
        <div className="main-content">
          <Topbar pageTitle="Inventory" shopName="Nanny's Shop" />
          <Breadcrumb currentPage="Inventory > New Inventory" />


          <Routes>
            <Route path="/inventory" element={<InventoryList />} />
            <Route path="/new-item" element={<NewInventoryItem />} />
            <Route path="/view-inventory" element={<InventoryView />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;

