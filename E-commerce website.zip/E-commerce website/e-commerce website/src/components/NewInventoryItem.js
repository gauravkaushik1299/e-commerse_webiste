
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import ReactQuill from 'react-quill';
import DatePicker from 'react-datepicker';
import 'react-quill/dist/quill.snow.css';
import 'react-datepicker/dist/react-datepicker.css';
import './NewInventoryItem.css';

// Importing assets at the top for better bundling
import DeleteIcon from '../assets/Delete.png';
import ImageIcon from '../assets/Image.png';
import UploadIcon from '../assets/fi_upload-cloud.png';

function NewInventoryItem({ }) {

  const [showDiscount, setShowDiscount] = useState(false);
  const [showDiscount1, setShowDiscount1] = useState(false);

  const [showExpiryDate, setShowExpiryDate] = useState(false);
  const [shortDescription, setShortDescription] = useState('');
  const [longDescription, setLongDescription] = useState('');
  const [dateAdded, setDateAdded] = useState(new Date());
  const [coverImage, setCoverImage] = useState(null);
  const [additionalImages, setAdditionalImages] = useState([null, null]);
  const handleCoverImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setCoverImage(URL.createObjectURL(file));
    }
  };

  const handleAdditionalImageChange = (index, e) => {
    const file = e.target.files[0];
    if (file) {
      const newAdditionalImages = [...additionalImages];
      newAdditionalImages[index] = URL.createObjectURL(file);
      setAdditionalImages(newAdditionalImages);
    }
  };


  // Moved these functions to the component level
  const deleteCoverImage = () => {
    setCoverImage(null);
  };

  const deleteAdditionalImage = (index) => {
    const newAdditionalImages = [...additionalImages];
    newAdditionalImages[index] = null;
    setAdditionalImages(newAdditionalImages);
  };

  return (
    <div className="new-inventory-item">
      <header className='header'>
        <h2 className='header-left'>New Inventory Item</h2>
        <div className="header-right">
          <select className='save-as-draft-button'>
            <option value="save">Save and Publish</option>
            <option value="draft">Save a Draft</option>
            <option value="publish">Publish</option>
          </select>
          <Link to="/view-inventory">
            <button type="submit" className='newitemsubmit'>Save & Publish</button>
          </Link>
        </div>
      </header>

      <div className='Summary'>
        <form className="inventory-form">
          <div className='card-inventory'>
            {/* Form Inputs */}
            <div className="form-left">
              <input type="text" placeholder="Product Name" />
              <select>
                <option>Select Product Category</option>
              </select>
              <div className="pricing">
                <input type="number" placeholder="Selling Price" />
                <input type="number" placeholder="Cost Price" />
              </div>
              <input type="number" placeholder="Quantity in Stock" />
              <select>
                <option>Order Type</option>
              </select>

              {/* Discount Toggle */}
              <div className="toggle-group">
                <label>
                  Discount&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <div className="toggle-switch">
                    <input
                      type="checkbox"
                      onChange={() => setShowDiscount(!showDiscount)}
                    />
                    <span className="slider"></span>
                  </div>
                </label>
              </div>
              {showDiscount && (
                <div className="conditional-input-group">
                  <input
                    type="number"
                    placeholder="Enter discount"
                    className="conditional-input"
                  />
                </div>
              )}

              {/* Expiry Date Toggle */}
              <div className="toggle-group">
                <label>
                  Expiry Date
                  <div className="toggle-switch">
                    <input
                      type="checkbox"
                      onChange={() => setShowExpiryDate(!showExpiryDate)}
                    />
                    <span className="slider"></span>
                  </div>
                </label>
              </div>
              {showExpiryDate && (
                <div className="conditional-input-group">
                  <input type="date" className="conditional-input" />
                </div>
              )}
            </div>

            <div className="text-group">
              {/* Short and Long Descriptions */}
              <textarea
                className="short-description"
                placeholder="Short Description"
                style={{ height: '167px' }}
                value={shortDescription}
                onChange={(e) => setShortDescription(e.target.value)}
              ></textarea>

              <label className="section-label">Product Long Description</label>
              <ReactQuill
                className="long-description"
                value={longDescription}
                onChange={setLongDescription}
                placeholder="Your text goes here"
                modules={{
                  toolbar: [
                    [{ font: [] }, { size: [] }],
                    ['bold', 'italic', 'underline', 'strike'],
                    [{ align: [] }],
                    [{ list: 'ordered' }, { list: 'bullet' }],
                    ['link'],
                  ],
                }}
              />

              {/* Additional Toggle for Discount */}
              <div className="toggle-group1">
                <span className="label">Return Policy</span>
                <span className="label">Add Discount</span>
                <label className="toggle-switch1">
                  <input
                    type="checkbox"
                    onChange={() => setShowDiscount1(!showDiscount1)}
                  />
                  <span className="slider1"></span>
                </label>
              </div>
              {showDiscount1 && (
                <div className="conditional-input-group">
                  <input type="number" placeholder="Enter discount" className="conditional-input" />
                </div>
              )}

              {/* Date Picker */}
              <label>Date Added</label>
              <div className="date-picker">
                <DatePicker
                  selected={dateAdded}
                  onChange={(date) => setDateAdded(date)}
                  dateFormat="MM/dd/yyyy"
                  placeholderText="Select Date"
                />
              </div>
            </div>
          </div>

          {/* Image Uploads */}
          <div className="card-inventory1">
            {/* Cover Image */}
            <div className="upload-section">
              <label className="upload-label">Upload Image</label>
              <div className="cover-image-upload">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleCoverImageChange}
                  id="coverImageInput"
                  style={{ display: 'none' }}
                />
                <label htmlFor="coverImageInput" className="upload-box">
                  {coverImage ? (
                    <div className="image-container">
                      <img src={coverImage} alt="Cover" className="uploaded-image" />
                      <button className="delete-button" onClick={deleteCoverImage}>
                        <img src={DeleteIcon} alt="Delete" />
                      </button>
                    </div>
                  ) : (
                    <div className="placeholder1">
                      <img src={ImageIcon} alt="Placeholder" />
                      <p>
                        <img src={UploadIcon} alt="Upload" /> &nbsp;&nbsp;Upload Image
                      </p>
                      <p className="upload-instructions">
                        Upload a Cover Image for your product<br></br>
                        File Format jpeg, png Recommended Size 600×600 (1:1)
                      </p>
                    </div>
                  )}
                </label>
              </div>
            </div>

            {/* Additional Images */}
            <div className="additional-images">
              <p className="additional-images-label">Additional Images</p>
              <div className="additional-images-grid">
                {additionalImages.map((image, index) => (
                  <div key={index} className="additional-image-upload">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleAdditionalImageChange(index, e)}
                      id={`additionalImageInput${index}`}
                      style={{ display: 'none' }}
                    />
                    <label htmlFor={`additionalImageInput${index}`} className="upload-box">
                      {image ? (
                        <div className="image-container">
                          <img src={image} alt={`Additional ${index + 1}`} className="uploaded-image" />
                          <button className="delete-button" onClick={() => deleteAdditionalImage(index)}>
                            <img src={DeleteIcon} alt="Delete" />
                          </button>
                        </div>
                      ) : (
                        <div className="placeholder">
                          <img src={ImageIcon} alt="Placeholder" />
                          <p>Upload Image</p>
                        </div>
                      )}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>

  );
}

export default NewInventoryItem;
