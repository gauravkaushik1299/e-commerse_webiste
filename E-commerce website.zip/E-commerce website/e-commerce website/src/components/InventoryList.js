

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './InventoryList.css';

function InventoryList() {
    const [statuses, setStatuses] = useState({});
    const [rowsPerPage, setRowsPerPage] = useState(2);
    const [page, setPage] = useState(1);
    const [selectAll, setSelectAll] = useState(false); // State for the "select all" checkbox
    const [selectedItems, setSelectedItems] = useState({});

    const handleStatusChange = (id, status) => {
        setStatuses((prevStatuses) => ({ ...prevStatuses, [id]: status }));
    };


    const inventory = [
        { id: 1, pic: <img src={require('../assets/row1.png')} alt="iPhone 13 Pro" width="36" height="36" />, name: 'iPhone 13 Pro', type: 'Gadgets', price: '₦1,225,000.00', stock: 8, discount: '₦0.00', total: '$50,000.00' },
        { id: 2, pic: <img src={require('../assets/row2.png')} alt="iPhone 12 Pro" width="36" height="36" />, name: 'iPhone 12 Pro', type: 'Gadgets', price: '₦725,000.00', stock: 12, discount: '₦0.00', total: '$50,000.00' },
        { id: 3, pic: <img src={require('../assets/row3.png')} alt="polo t-shirt" width="36" height="36" />, name: 'Polo T-Shirt', type: 'Fashion', price: '₦125,000.00', stock: 120, discount: '₦0.00', total: '$50,000.00' },
        { id: 4, pic: <img src={require('../assets/row3.png')} alt="polo t-shirt" width="36" height="36" />, name: 'Polo T-Shirt', type: 'Fashion', price: '₦125,000.00', stock: 'Out of Stock', discount: '₦0.00', total: '$0.00' },
        { id: 5, pic: <img src={require('../assets/row3.png')} alt="polo t-shirt" width="36" height="36" />, name: 'Polo T-Shirt', type: 'Fashion', price: '₦125,000.00', stock: 'Out of Stock', discount: '₦0.00', total: '$0.00' },
        { id: 6, pic: <img src={require('../assets/row1.png')} alt="iPhone 13 Pro" width="36" height="36" />, name: 'iPhone 13 Pro', type: 'Gadgets', price: '₦1,225,000.00', stock: 8, discount: '₦0.00', total: '$50,000.00' },
        { id: 7, pic: <img src={require('../assets/row2.png')} alt="iPhone 12 Pro" width="36" height="36" />, name: 'iPhone 12 Pro', type: 'Gadgets', price: '₦725,000.00', stock: 12, discount: '₦0.00', total: '$50,000.00' },
        { id: 8, pic: <img src={require('../assets/row1.png')} alt="iPhone 13 Pro" width="36" height="36" />, name: 'iPhone 13 Pro', type: 'Gadgets', price: '₦1,225,000.00', stock: 8, discount: '₦0.00', total: '$50,000.00' },
        { id: 9, pic: <img src={require('../assets/row2.png')} alt="iPhone 12 Pro" width="36" height="36" />, name: 'iPhone 12 Pro', type: 'Gadgets', price: '₦725,000.00', stock: 12, discount: '₦0.00', total: '$50,000.00' },
        { id: 10, pic: <img src={require('../assets/row3.png')} alt="polo t-shirt" width="36" height="36" />, name: 'Polo T-Shirt', type: 'Fashion', price: '₦125,000.00', stock: 120, discount: '₦0.00', total: '$50,000.00' }
    ];
    const handleSelectAllChange = () => {
        const newSelectAll = !selectAll;
        setSelectAll(newSelectAll);
        const newSelectedItems = inventory.reduce((acc, item) => {
            acc[item.id] = newSelectAll;
            return acc;
        }, {});
        setSelectedItems(newSelectedItems);
    };

    const handleItemSelectChange = (id) => {
        setSelectedItems((prev) => ({
            ...prev,
            [id]: !prev[id]
        }));
    };

    const handleChange = (e) => {
        setRowsPerPage(Number(e.target.value));
    };

    return (
        <div>
            <div className="container">
                <div className="row">
                    <div className="Text">
                        <h2>Inventory Summary
                        </h2>
                    </div>
                </div>
                <div className="row nav">
                    <div className="nav">
                        <Link to="/new-item">
                            <button className="nav-button"> +Add a new product</button>
                        </Link>
                    </div>
                </div>
            </div>

            <div className="summary-cards">
                <div className="card1">
                    <div className="icon-placeholder"><img src={require('../assets/Inventory.png')}></img></div>
                    <div className="card-content">
                        <p>All Products&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            Active<br></br>
                            350&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            312
                        </p>
                    </div>
                </div>
                <div className="card2">
                    <div className="icon-placeholder1"><img src={require('../assets/icon.png')}></img>

                        <select className="time-filter">
                            <option>Today</option>
                            <option>This Week</option>
                            <option>This Month</option>
                            <option>This Year</option>
                        </select>
                    </div>
                    <div className="card-content1">
                        <p className='text1' style={{ marginLeft: '-140px' }}>Low Stock Alert</p>
                        <p>Expired</p><p> 1 Star Rating</p>
                    </div>
                    <div className="card-content1">
                        <p style={{ marginLeft: '-140px', marginTop: '-10px' }}>23</p><p style={{ marginTop: '-10px' }}>3</p><p style={{ marginTop: '-10px' }}>2</p>
                    </div>

                </div>
            </div>



            <div className='card-inventory-list'>
                <div className="header-inventory-list">
                    <div className="row">
                        <p>Inventory Items &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </p>
                    </div>
                    <input type="text" className="search-bar" placeholder="Search..." />

                    <button className="filter-btn"><img src={require('../assets/fi_filter.png')}></img> &nbsp;Filter</button>
                    <button className="share-btn"><img src={require('../assets/Send.png')}></img>&nbsp;Share</button>
                    <select className="bulk-action">
                        <option>Bulk Action</option>
                        <option>Delete Selected</option>
                        <option>Export Selected</option>
                    </select>

                </div>
                <table className="inventory-table">
                    <thead>
                        <tr>
                            <th>
                                <input type="checkbox" className="square-radio1" checked={selectAll} onChange={handleSelectAllChange} />
                            </th>
                            <th></th>
                            <th>Product Name&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                            <th>Category&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                            <th>Unit Price&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                            <th>In-Stock&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                            <th>Discount&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                            <th>Total Value&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                            <th>Action&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                            <th>Status&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                        </tr>
                    </thead>
                    <tbody>
                        {inventory.slice((page - 1) * rowsPerPage, page * rowsPerPage).map((item) => (
                            <tr key={item.id}>
                                <td>
                                    <input type="checkbox" className="square-radio" checked={selectedItems[item.id] || false} onChange={() => handleItemSelectChange(item.id)} />
                                </td>
                                <td className='image'>{item.pic}</td>
                                <td>{item.name}</td>
                                <td>{item.type}</td>
                                <td>{item.price}</td>
                                <td>{item.stock}</td>
                                <td>{item.discount}</td>
                                <td>{item.total}</td>
                                <td>
                                    <select
                                        value={statuses[item.id] || 'published'}
                                        onChange={(e) => handleStatusChange(item.id, e.target.value)}
                                    >
                                        <option value="published">Publish</option>
                                        <option value="unpublished">Unpublish</option>
                                    </select>
                                </td>
                                <td>{statuses[item.id] || 'published'}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                <div className="pagination">
                    <p className='text'>
                        <select className="number-filter" value={rowsPerPage} onChange={handleChange}>
                            <option>2</option>
                            <option>4</option>
                            <option>6</option>
                            <option>8</option>
                            <option>10</option>
                        </select>&nbsp;&nbsp; Items per page
                    </p>
                    <p className='text-pagination'>
                        {(page - 1) * rowsPerPage + 1} - {Math.min(page * rowsPerPage, inventory.length)} of {inventory.length} items
                    </p>
                    <p className='text-pagination2'>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        Page:&nbsp;
                        <select className="page-filter" value={page} onChange={(e) => setPage(parseInt(e.target.value, 10))}>
                            {Array.from({ length: Math.ceil(inventory.length / rowsPerPage) }, (_, i) => (
                                <option key={i + 1} value={i + 1}>{i + 1}</option>
                            ))}
                        </select> of 44
                        &nbsp;
                        <span className="page-link" onClick={() => setPage(Math.max(page - 1, 1))}>&lt;</span>&nbsp;
                        <span className="page-link" onClick={() => setPage(Math.min(page + 1, Math.ceil(inventory.length / rowsPerPage)))}>&gt;</span>
                    </p>
                </div>
            </div>
        </div>
    );
}

export default InventoryList;


