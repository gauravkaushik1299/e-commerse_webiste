import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import '../components/Breadcrumb.css';

function Breadcrumb() {
  const location = useLocation();

  const getPath = () => {
    switch (location.pathname) {
      case '/inventory':
        return (
          <div className='case'>
            <Link to="/"><img src={require('../assets/Home.png')}></img></Link> / Inventory
          </div>
        );
      case '/new-item':
        return (
          <div className='case'>
            <Link to="/"><img src={require('../assets/Home.png')}></img></Link> / <Link to="/inventory">Inventory</Link> / New Inventory
          </div>
        );
      case '/view-inventory':
        return (
          <div className='case'>
            <Link to="/"><img src={require('../assets/Home.png')}></img></Link> / <Link to="/inventory">Inventory</Link> / <Link to="/new-item">New Inventory</Link> / View Inventory
          </div>
        );
      default:
        return <div className='case'><Link to="/"><img src={require('../assets/Home.png')}></img></Link></div>;
    }
  };

  return <div className="breadcrumb">{getPath()}</div>;
}

export default Breadcrumb;

