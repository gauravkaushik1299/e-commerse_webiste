
import React from 'react';
import './InventoryView.css';
import PurchasesTable from './PurchasesTable.js';


function InventoryView() {
    // Mock data for cards
    const cardData = {
        price: "₦25,000.00",
        inStock: 20,
        totalOrders: "₦50,000.00",
        views: 1200,
        favorite: 23,
        orders: {
            all: 1,
            pending: 0,
            completed: 1,
            canceled: 0,
            returned: 0,
            damaged: 0
        }
    };

    return (
        <div className="inventory-view">
            <div className="header">
                <div className="heading">
                    <p style={{ fontSize: '16px', fontWeight: 'bold', color: '#45464E' }}>Polo T-Shirt</p>
                    <p className='text-color'><span>Date Added:</span><span> 12 Sept 2022 - 12:55 pm</span></p>
                    <p className='text-color1'>
                        <span>Product URL:</span>
                        <span> 1nancystores.com/polot-shirt&nbsp;&nbsp;
                            <img src={require('../assets/u_copy-alt.png')} alt="Copy Icon" className="copy-icon" />
                        </span>
                    </p>
                </div>
                <div className="actions">
                    <button className="edit-button">Edit Product&nbsp;&nbsp;</button>
                    <button className="unpublish-button">Unpublish Product</button>
                </div>
            </div>

            <div className="product-info">
                {/* Product Image */}
                <div className="card image-card">
                    <img src={require("../assets/image_1.png")} alt="Product" />
                </div>

                {/* Product Details */}
                <div className="card details-card">
                    <p>Last Order <strong>12 Sept 2022</strong>
                        <span className="status">Published</span>
                    </p>
                    <div className="price-stock">
                        <p>Price<br /><strong>₦25,000.00</strong></p>
                        <p>In-Stock<br /><strong>20</strong></p>
                    </div>
                </div>

                {/* Orders Summary */}
                <div className="card orders-card">
                    <div className="icon">
                        <img src={require("../assets/dashboardsummarycardicon.png")} alt="Orders Icon" />
                        <select className="time-filter">
                            <option>Today</option>
                            <option>This Week</option>
                            <option>This Month</option>
                            <option>This Year</option>
                        </select>
                    </div>
                    <p className='total-orders'>Total Orders<br /><strong>₦50,000.00</strong></p>
                </div>

                {/* Views & Favorites */}
                <div className="card views-favorites-card">
                    <div className="icon1">
                        <img src={require("../assets/icon (1).png")} alt="Views Icon" />
                        <select className="time-filter1">
                            <option>Today</option>
                            <option>This Week</option>
                            <option>This Month</option>
                            <option>This Year</option>
                        </select>
                    </div>
                    <p>Views<br /><strong>1,200</strong></p>
                </div>
            </div>

            {/* Additional Orders and Purchases Summary */}
            <div className="additional-info">
                {/* Orders Summary Card */}
                <div className="card orders-summary-card">
                    <div className="top">
                        <img src={require("../assets/icon (2).png")} alt="Orders Summary Icon" />
                        <select className="time-filter2">
                            <option>Today</option>
                            <option>This Week</option>
                            <option>This Month</option>
                            <option>This Year</option>
                        </select>
                    </div>
                    <div className="bottom">
                        <div>
                            <p>All Orders</p>
                            <p>{cardData.orders.all}</p>
                        </div>
                        <div>
                            <p>Pending</p>
                            <p>{cardData.orders.pending}</p>
                        </div>
                        <div>
                            <p>Completed</p>
                            <p>{cardData.orders.completed}</p>
                        </div>
                    </div>
                </div>

                {/* Purchases Summary Card */}
                <div className="card purchases-summary-card">
                    <div className="top">
                        <img src={require("../assets/icon (2).png")} alt="Purchases Summary Icon" />
                        <select className="time-filter2">
                            <option>Today</option>
                            <option>This Week</option>
                            <option>This Month</option>
                            <option>This Year</option>
                        </select>
                    </div>
                    <div className="bottom">
                        <div>
                            <p>Canceled</p>
                            <p>{cardData.orders.canceled}</p>
                        </div>
                        <div>
                            <p>Returned</p>
                            <p>{cardData.orders.returned}</p>
                        </div>
                        <div>
                            <p>Damaged</p>
                            <p>{cardData.orders.damaged}</p>
                        </div>
                    </div>

                </div>
            </div>

            <PurchasesTable />
        </div>
    );
}

export default InventoryView;
