import React, { useState } from 'react';
import './PurchasesTable.css';

function PurchasesTable() {
    const [isAllSelected, setIsAllSelected] = useState(false);
    const [selectedItems, setSelectedItems] = useState({});

    const purchases = [
        {
            id: 1,
            date: "12 Aug 2022 - 12:25 am",
            type: "Home Delivery",
            unitPrice: "₦25,000.00",
            qty: 2,
            discount: "₦0.00",
            total: "₦50,000.00",
            status: "Completed"
        },
        // Add more purchase data as needed or fetch using api
    ];

    // Toggle all checkboxes
    const handleSelectAllChange = () => {
        const newIsAllSelected = !isAllSelected;
        setIsAllSelected(newIsAllSelected);

        const newSelectedItems = {};
        purchases.forEach(purchase => {
            newSelectedItems[purchase.id] = newIsAllSelected;
        });
        setSelectedItems(newSelectedItems);
    };

    // Toggle individual checkbox
    const handleCheckboxChange = (id) => {
        setSelectedItems(prevSelectedItems => ({
            ...prevSelectedItems,
            [id]: !prevSelectedItems[id]
        }));
    };

    return (
        <div className="purchases-table">
            <div className="header-vieworder-list">
                <div className="row">
                    <p>Purchases&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </p>
                </div>
                <input type="text" className="search-bar" placeholder="Search..." />

                <button className="filter-btn">
                    <img src={require('../assets/fi_filter.png')} alt="Filter" />
                    &nbsp;Filter
                </button>
                <button className="share-btn">
                    <img src={require('../assets/Send.png')} alt="Share" />
                    &nbsp;Share
                </button>
                <select className="bulk-action">
                    <option>Bulk Action</option>
                    <option>Delete Selected</option>
                    <option>Export Selected</option>
                </select>
            </div>
            <table className="view-order-table">
                <thead>
                    <tr>
                        <th>
                            <input
                                type="checkbox"
                                className="square-radio"
                                checked={isAllSelected}
                                onChange={handleSelectAllChange}
                            />
                        </th>
                        <th>Order Date&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                        <th>Order Type&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                        <th>Unit Price&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                        <th>Qty&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                        <th>Discount&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                        <th>Order Total&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                        <th>Status&nbsp;&nbsp;<img src={require('../assets/sort.png')}></img></th>
                    </tr>
                </thead>
                <tbody>
                    {purchases.map((purchase) => (
                        <tr key={purchase.id}>
                            <td>
                                <input
                                    type="checkbox"
                                    className="square-radio"
                                    checked={!!selectedItems[purchase.id]}
                                    onChange={() => handleCheckboxChange(purchase.id)}
                                />
                            </td>
                            <td>{purchase.date}</td>
                            <td>{purchase.type}</td>
                            <td>{purchase.unitPrice}</td>
                            <td>{purchase.qty}</td>
                            <td>{purchase.discount}</td>
                            <td>{purchase.total}</td>
                            <td className={`status-${purchase.status.toLowerCase()}`}>{purchase.status}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default PurchasesTable;
