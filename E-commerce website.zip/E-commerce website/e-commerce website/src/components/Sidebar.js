import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import LogoImage from './LogoImage';
import './sidebar.css';

function Sidebar() {
  const location = useLocation();

  const isActive = (path) => location.pathname === path;

  return (
    <div className="sidebar">
      <LogoImage />
      <div className="sidebar-icons">
        <Link to="/category" className={isActive('/category') ? 'active' : ''}>
          <img src={require('../assets/Category.png')}></img>
        </Link>
        <Link to="/bag" className={isActive('/bag') ? 'active' : ''}>
          <img src={require('../assets/Bag.png')}></img>
        </Link>
        <Link to="/users" className={isActive('/users') ? 'active' : ''}>
          <img src={require('../assets/users.png')}></img>
        </Link>
        <Link to="/inventory" className={isActive('/inventory') ? 'active' : ''}>
          <img src={require('../assets/Inventory.png')}></img>
        </Link>
        <Link to="/messages" className={isActive('/messages') ? 'active' : ''}>
          <img src={require('../assets/Comments.png')}></img>
        </Link>
        <Link to="/settings" className={isActive('/settings') ? 'active' : ''}>
          <img src={require('../assets/Settings.png')}></img>
        </Link>
      </div>
      <div className='sidebar-icons-2'>
        <Link to="/contact-us" className={isActive('/contact-us') ? 'active' : ''}>
          <img src={require('../assets/fi_headphones.png')}></img>
        </Link>
        <Link to="/vouchers" className={isActive('/vouchers') ? 'active' : ''}>
          <img src={require('../assets/gifticon.png')}></img>
        </Link>

      </div>

      <button onClick={() => alert("You have been logged out.")} className="logout-button">
        <img src={require('../assets/Logout.png')}></img>
      </button>
    </div>
  );
}

export default Sidebar;
