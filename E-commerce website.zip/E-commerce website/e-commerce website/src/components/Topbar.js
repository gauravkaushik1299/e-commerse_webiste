
import React from 'react';
import './LogoImage.css';
import './Topbar.css';

function Topbar({ pageTitle = "Inventory", shopName = "Nanny's Shop" }) {
  return (
    <div className="topbar">
      <h1 className="page-title">{pageTitle}</h1>
      <div className="topbar-right">
        <select className="dropdown">
          <option className="shop-name">{shopName}</option>
        </select>
        <img src={require('../assets/Notification.png')}></img>
        <div className='profile-pic'>
          <img src={require('../assets/profilepic.png')}></img>
        </div>
      </div>
    </div>
  );
}

export default Topbar;
