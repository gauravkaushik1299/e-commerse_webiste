import React from 'react';
import '../components/LogoImage.css';


function LogoImage() {
  return (
    <div className="logo-container">
      <img src={require('../assets/phantasm_logo_icon_-01_480 1.png')} alt="Logo" className="logo-placeholder" />
    </div>
  );
}

export default LogoImage;

